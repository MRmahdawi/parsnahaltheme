
<?php get_header();?>
<article class="article-single">

    <div class="contain single">
    <header class="header-post">
    <img src="img/single-post.png" alt="#" title="#">
    </header>
    <div class="post-body-single-header">

    <div class="head-body-single">
        <h1>نهال سیب فرانسه اصلاح شده</h1>
        <a href="#">لیست ارقام نهال سیب</a>
    </div>
        <div class="contant-single-head">
            <div class="deata-table">

                <table class="single-table">
                    <tbody>
                    <tr class="">
                        <th class=""><b>آب هوا</b></th>
                        <td class=""><p>سرد سیر و معتدل</p>
                        </td>
                    </tr>
                    <tr class="">
                        <th class=""><b>میزان بار دهی</b></th>
                        <td class=""><p>زیاد</p>
                        </td>
                    </tr>
                    <tr class="">
                        <th class=""><b>عمر اقتصادی</b></th>
                        <td class=""><p>زیاد و منحصر به فرد</p>
                        </td>
                    </tr>
                    <tr class="">
                        <th class=""><b>آبیاری</b></th>
                        <td class=""><p>منظم و متوسط</p>
                        </td>
                    </tr>
                    <tr class="">
                        <th class=""><b>زمان کاشت</b></th>
                        <td class=""><p>منظم و متوسط</p>
                        </td>
                    </tr>
                    </tbody></table>





                <div class="buy">


                    <div class="gheymat">
                        <b>قیمت : </b>
                        <p class="takhfif">
                            13600 تومان
                        </p>
                        <p class="gheymat-orginal">
                            127000 تومان
                        </p>
                        <div class="mizan-takhfif">
                            11% تخفیف
                        </div>
                    </div>
                    <div class="cat">
                        <b> دسته : </b>
                        <a href="#">نهال سیب </a>
                    </div>


                    <div class="tedad">
                        <b>تعداد : </b>
                        <div class="quantity">
                        <button type="button" class="minus">-</button>
                        <input type="number" id="" class="qty" step="1" min="1" max="" name="quantity" value="1" title="تعداد" size="4" placeholder="" inputmode="numeric" autocomplete="off">
                        <button type="button" class="plus">+</button>	</div>
                      </div>

                     <div class="btn-kharid">
                    <a href="#">
                        <b>افزودن به سبد خرید</b>
                    </a>
                </div>
                </div>

            </div>

        </div>

        <div class="matn-kotah">
            <p>            <b>معرفی کوتاه :</b>
                 بله برای خرید های بالای 5 ملیون تومان هزینه ارسال دریافت نمیشود  همچنین برای خرید های بالای ده ملیون  تومان 5  نهال هدیه برای شما ارسال میشود  نهال هدیه برای شما ارسال میشود شما ارسال میشود  نهال هدیه برای شما ارسال میشود  </p>
        </div>
    </div>

    </div>


 <div class=" contain call-single">
     <p> هر سوالی داشتی در باره این نهال 24 ساعته میتونی با ما تماس بگیری  </p>
     <div class="call-number">

         <div class="call-one">
             <a href="#">09380777108</a>
         </div>
         <div class="call-one">
             <a href="#">09380777108</a>
         </div>
     </div>
 </div>

    <div class="centerr">

<div class=" contain container-text-and-right-single">
    <div class="articel-single-text jstab">

        <div class="btn--tab-single tabs">
            <button class="btn-tab active" onclick="changeTab(event, 'tab1')"> معرفی  </button>
            <button class="btn-tab" onclick="changeTab(event, 'tab2')">  مشخصات  </button>
            <button class="btn-tab" onclick="changeTab(event, 'tab3')"> سوالات + نظرات </button>
        </div>


        <div id="tab1" class="articel-text activer">

            <h1>
                سرتیتر اول با توضیح
            </h1>
            <p>
                درخت آن در صورت رسیدگی مناسب تا ارفاع 7 متر میرسید و عرض آن میانگین 8 متر محصول آن مانند انگور به صورت خوشه ای میباشد و در هر خوشه
                آن حدودا 8 الی 12 گردو وجود دارد که پوستی نازک دارد و با دست براحتی قابل شکستن است رنگ آن نیز روشن است
            </p>

            <h2>
                سرتیتر دوم با توضیح
            </h2>
            <p>
                درخت آن در صورت رسیدگی مناسب تا ارفاع 7 متر میرسید و عرض آن میانگین 8 متر محصول آن مانند انگور به صورت خوشه ای میباشد و در هر خوشه
                آن حدودا 8 الی 12 گردو وجود دارد که پوستی نازک  دارد  و با دست براحتی قابل شکستن  است رنگ  آن  نیز  روشن است  درخت آن در صورت رسیدگی
                مناسب تا ارفاع 7  متر میرسید  و عرض  آن میانگین 8 متر محصول آن مانند انگور به   صورت خوشه ای میباشد و در هر خوشه آن حدودا 8 الی 12 گردو
                وجود دارد که پوستی نازک دارد و با دست براحتی قابل شکستن است رنگ آن نیز روشن است
            </p>
            <img src="img/articel-image.png" alt="#" title="#">

            <h3>سرتیتر سوم  با توضیح</h3>
            <p>
                درخت آن در صورت رسیدگی مناسب تا ارفاع 7 متر میرسید و عرض آن میانگین 8 متر محصول آن مانند انگور به صورت خوشه ای میباشد و در هر خوشه
                آن حدودا 8 الی 12 گردو وجود دارد که پوستی نازک دارد و با دست براحتی قابل شکستن است رنگ آن نیز روشن است
            </p>

            <h4>سرتیتر چهارم با توضیح</h4>
            <p>
                درخت آن در صورت رسیدگی مناسب تا ارفاع 7 متر میرسید و عرض آن میانگین 8 متر محصول آن مانند انگور به صورت خوشه ای میباشد و در هر  <a href="#">بهترین زمان کاشت</a>
                آن حدودا 8 الی 12 گردو وجود دارد که پوستی نازک  دارد  و با دست براحتی قابل شکستن  است رنگ  آن  نیز  روشن است  درخت آن در صورت رسیدگی
                مناسب تا ارفاع 7  متر میرسید  و عرض  آن میانگین 8 متر محصول آن مانند انگور به   صورت خوشه ای میباشد و در هر خوشه آن حدودا 8 الی 12 گردو
                وجود دارد که پوستی نازک دارد و با دست براحتی قابل شکستن است رنگ آن نیز روشن است
            </p>

            <b>سرتیتر B با توضیح</b>

            <ul>
                <li>بهترین زمان کاشت</li>
                <li>بهترین زمان کاشت</li>
                <li>بهترین زمان کاشت</li>
                <li>بهترین زمان کاشت</li>

            </ul>
        </div>
        <div id="tab2" class="articel-text">
            تب دوم تست متن
        </div>
        <div id="tab3" class="articel-text ">
            تب سوم تست متن
        </div>

            <div class="mortabet">
                <h3>لیست زیرم ببین</h3>
                <div class="list-mortabet">
                    <div class="list-box">
                        <a href="#"><img src="img/single-pos-mohtava.png" alt="" title=""> </a>
                        <a href="#">نهال سیب مراغه  </a>
                    </div>
                    <div class="list-box">
                        <a href="#"><img src="img/single-pos-mohtava.png" alt="" title=""> </a>
                        <a href="#">نهال سیب مراغه  </a>
                    </div>
                    <div class="list-box">
                        <a href="#"><img src="img/single-pos-mohtava.png" alt="" title=""> </a>
                        <a href="#">نهال سیب مراغه  </a>
                    </div>
                    <div class="list-box">
                        <a href="#"><img src="img/single-pos-mohtava.png" alt="" title=""> </a>
                        <a href="#">نهال سیب مراغه  </a>
                    </div>
                    <div class="list-box">
                        <a href="#"><img src="img/single-pos-mohtava.png" alt="" title=""> </a>
                        <a href="#">نهال سیب مراغه  </a>
                    </div>



                </div>
            </div>
    </div>
    <div class="right-single">
        <div class="header-rigjt">
            <h3>پر فروش ها</h3>
        </div>

        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>
        <a  href="#" class="box-right">
            <img src="img/single-post.png" alt="#" title="#">
            <b>نهال گردو چندلر وارداتی با کیفیت عالی</b>
        </a>

        <div class="all-shop">
            <a href="#"> + مشاهده تمام نهال ها</a>
        </div>
    </div>
</div>




    </div>

</article>
<div class="free-tree">
    <h2>  نهال رایگان میخای ؟</h2>
    <p> شماره تماستو  ثبت کن و نهال رایگان هدیه بگیر از طرف ما  </p>
    <form class="fonrmm">
        <input  class="type-number" placeholder="09123456789" type="text">
        <button>ثبت</button>
        <div class="khat"></div>
    </form>
</div>

<footer class="footer-all">
    <div class="contain foot ">
        <div class="footer-one">
            <div class="logofooter">
                <img src="img/logo-footer.png" alt="#" title="#">
            </div>
            <p>
                پارس نهال بزرگترین مرکز تولید و تکثیر نهال در کشور
                با  تضمین بازگشت یا تعویض نهال در صورت نارضایتی
                و سبز نشدن گیاه با ما تماس بگیرید.
            </p>
        </div>

        <div class="footer-tow">
            <div class="title-footer">
                <h3>راهنمای کاربر </h3>
            </div>
            <ul>
                <li><a href="#">آموزش خرید</a></li>
                <li><a href="#">مشاهده محصولات</a></li>
                <li><a href="#">آموزش پرداخت</a></li>
                <li><a href="#">خرید حضوری</a></li>

            </ul>
        </div>

        <div class="footer-tow">
            <div class="title-footer">
                <h3>لینک های مهم </h3>
            </div>
            <ul>
                <li><a href="#">آموزش خرید</a></li>
                <li><a href="#">مشاهده محصولات</a></li>
                <li><a href="#">آموزش پرداخت</a></li>
                <li><a href="#">خرید حضوری</a></li>

            </ul>
        </div>

        <div class="footer-tow">
            <div class="title-footer">
                <h3> سوالی داری زنگ بزن :) </h3>
            </div>
            <div class="number-footer">
                <div class="num"><b>مهندس فرجی (فروش)</b> </div>
                <div class="num">09380777108</div>
            </div>


            <div class="number-footer">
                <div class="num"><b>مهندس پور محمد</b> </div>
                <div class="num">09380777108</div>
            </div>


            <div class="number-footer">
                <div class="num"><b>مهندس پور محمد</b> </div>
                <div class="num">09380777108</div>
            </div>



        </div>

    </div>
    <div class="f-a-r-s-h-a-d">
        پارس نهال بزرگترین مرکز تولید و تکثیر نهال در کشور
    </div>
</footer>
</body>
</html>